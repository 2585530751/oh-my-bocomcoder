# Fix a bug in `provider-retry.ts`

Optional chaining was removed from a property access.

Replace this (starting on line 93):

```ts
        signal.removeEventListener('abort', onAbort);
```

with:

```ts
        signal?.removeEventListener('abort', onAbort);
```

Make exactly this change; do not modify anything else.