# Fix a bug in `shell-output.ts`

Optional chaining was removed from a property access.

The bug is in the `executeShellWithCapture` function.

Replace this:

```ts
      env: options.env,
```

with:

```ts
      env: options?.env,
```

Make exactly this change; do not modify anything else.