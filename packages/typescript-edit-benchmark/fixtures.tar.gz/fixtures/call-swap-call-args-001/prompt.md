# Fix a bug in `custom-compaction.ts`

Two arguments in a call are swapped.

Replace this (starting on line 48):

```ts
      ctx.ui.notify('warning', `No API key for ${model.provider}, using default compaction`);
```

with:

```ts
      ctx.ui.notify(`No API key for ${model.provider}, using default compaction`, 'warning');
```

Make exactly this change; do not modify anything else.