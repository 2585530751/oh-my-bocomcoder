# Fix a bug in `branch-summarization.ts`

Two arguments in a call are swapped.

The bug is in the `generateBranchSummary` function.

Replace this:

```ts
  const { messages, fileOps } = prepareBranchEntries(tokenBudget, entries);
```

with:

```ts
  const { messages, fileOps } = prepareBranchEntries(entries, tokenBudget);
```

Make exactly this change; do not modify anything else.