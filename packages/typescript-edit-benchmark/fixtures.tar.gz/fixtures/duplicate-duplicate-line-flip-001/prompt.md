# Fix a bug in `mime.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this (starting on line 52):

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'IDAT')) return true;
```

with:

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'IDAT')) return false;
```

Make exactly this change; do not modify anything else.