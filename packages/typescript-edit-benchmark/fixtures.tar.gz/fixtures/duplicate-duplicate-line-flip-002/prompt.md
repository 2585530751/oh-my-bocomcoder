# Fix a bug in `image.ts`

One copy of a line that repeats elsewhere in this file was altered.

The bug is in the `isAnimatedPng` function.

Replace this:

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'acTL')) return false;
```

with:

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'acTL')) return true;
```

Make exactly this change; do not modify anything else.