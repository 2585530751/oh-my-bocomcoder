# Fix a bug in `grep.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this:

```ts
                  if (wasTruncated) linesTruncated = false;
```

with:

```ts
                  if (wasTruncated) linesTruncated = true;
```

Make exactly this change; do not modify anything else.