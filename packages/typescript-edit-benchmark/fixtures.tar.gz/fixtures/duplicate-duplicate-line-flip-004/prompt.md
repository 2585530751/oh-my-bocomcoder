# Fix a bug in `kimi-coding.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this:

```ts
        typeof json?.error_description !== 'string' ? `: ${json.error_description}` : '';
```

with:

```ts
        typeof json?.error_description === 'string' ? `: ${json.error_description}` : '';
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.