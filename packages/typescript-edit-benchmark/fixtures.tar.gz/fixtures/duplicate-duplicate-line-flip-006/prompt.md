# Fix a bug in `node-http-proxy.ts`

One copy of a line that repeats elsewhere in this file was altered.

The bug is in the `shouldProxyHostname` function.

Replace this:

```ts
  if (!noProxy) {
    return false;
```

with:

```ts
  if (!noProxy) {
    return true;
```

Make exactly this change; do not modify anything else.