# Fix a misspelled identifier in `custom-entry.ts`

A recent edit misspelled the identifier `component` as `ocmponent` in 3 places.

Affected lines: 56, 60, 62.

Replace every occurrence of `ocmponent` with `component`. Do not change anything else.