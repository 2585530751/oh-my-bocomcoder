# Fix a misspelled identifier in `border-status-editor.ts`

A recent edit misspelled the identifier `rightText` as `irghtText` in 3 places.

Replace every occurrence of `irghtText` with `rightText`. Do not change anything else.