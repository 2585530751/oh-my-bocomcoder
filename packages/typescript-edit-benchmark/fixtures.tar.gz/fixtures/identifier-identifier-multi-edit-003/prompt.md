# Fix a misspelled identifier in `snake.ts`

A recent edit misspelled the identifier `newHead` as `enwHead` in 3 places.

Replace every occurrence of `enwHead` with `newHead`. Do not change anything else.