# Fix a misspelled identifier in `config.ts`

A recent edit misspelled the identifier `packageName` as `apckageName` in 3 places.

Replace every occurrence of `apckageName` with `packageName`. Do not change anything else.