# Fix a misspelled identifier in `paths.ts`

A recent edit misspelled the identifier `normalized` as `onrmalized` in 2 places.

Affected lines: 63, 78.

Replace every occurrence of `onrmalized` with `normalized`. Do not change anything else.