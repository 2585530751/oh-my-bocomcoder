# Fix a misspelled identifier in `agent-session-services.ts`

A recent edit misspelled the identifier `resourceLoader` as `ersourceLoader` in 3 places.

Replace every occurrence of `ersourceLoader` with `resourceLoader`. Do not change anything else.