# Fix a misspelled identifier in `session.ts`

A recent edit misspelled the identifier `summary` as `usmmary` in 3 places.

Replace every occurrence of `usmmary` with `summary`. Do not change anything else.