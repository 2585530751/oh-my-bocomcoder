# Fix a misspelled identifier in `tools-manager.ts`

A recent edit misspelled the identifier `response` as `ersponse` in 2 places.

Replace every occurrence of `ersponse` with `response`. Do not change anything else.