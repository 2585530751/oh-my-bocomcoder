# Fix a bug in `user-message.ts`

A boolean literal is inverted.

Replace this (starting on line 43):

```ts
        { preserveOrderedListMarkers: true, preserveBackslashEscapes: false },
```

with:

```ts
        { preserveOrderedListMarkers: true, preserveBackslashEscapes: true },
```

Make exactly this change; do not modify anything else.