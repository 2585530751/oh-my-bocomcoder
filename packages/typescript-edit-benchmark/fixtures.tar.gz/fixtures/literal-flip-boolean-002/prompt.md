# Fix a bug in `paths.ts`

A boolean literal is inverted.

The bug is in the `isLocalPath` function.

Replace this:

```ts
    return true;
```

with:

```ts
    return false;
```

Make exactly this change; do not modify anything else.