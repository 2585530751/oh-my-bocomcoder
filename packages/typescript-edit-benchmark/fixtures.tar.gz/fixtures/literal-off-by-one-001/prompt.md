# Fix a bug in `loader.ts`

A numeric boundary has an off-by-one error.

Replace this (starting on line 68):

```ts
      indicator?.intervalMs && indicator.intervalMs > 1
```

with:

```ts
      indicator?.intervalMs && indicator.intervalMs > 0
```

Make exactly this change; do not modify anything else.