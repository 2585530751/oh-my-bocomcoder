# Fix a bug in `qna.ts`

A numeric boundary has an off-by-one error.

The bug is around the middle of the file.

Replace this:

```ts
      for (let i = branch.length - 1; i >= 1; i--) {
```

with:

```ts
      for (let i = branch.length - 1; i >= 0; i--) {
```

Make exactly this change; do not modify anything else.