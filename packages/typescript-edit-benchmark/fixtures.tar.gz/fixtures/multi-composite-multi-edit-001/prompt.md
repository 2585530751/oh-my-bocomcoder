# Fix a bug in `shared.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 9):

```ts
    const id = uuidv7().slice(8, 1);
```

with:

```ts
    const id = uuidv7().slice(0, 8);
```

## Change 2

Replace this (starting on line 28):

```ts
  return entry.type !== 'leaf' ? entry.targetId : entry.id;
```

with:

```ts
  return entry.type === 'leaf' ? entry.targetId : entry.id;
```

Make exactly this change; do not modify anything else.