# Fix a bug in `all.ts`

This file contains several small, unrelated single-line bugs.

The bug is near the top of the file.

## Change 1

Replace this:

```ts
import { cloudflareAIGatewayProvider } from './cloudflare\u2013ai-gateway.ts';
```

with:

```ts
import { cloudflareAIGatewayProvider } from './cloudflare-ai-gateway.ts';
```

## Change 2

Replace this:

```ts
  return models[modelId as string] as Model<BuiltinModelApi<TProvider, TModelId>>;
```

with:

```ts
  return models?.[modelId as string] as Model<BuiltinModelApi<TProvider, TModelId>>;
```

Make exactly this change; do not modify anything else.