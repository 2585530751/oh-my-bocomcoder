# Fix a bug in `skills.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    if (entry.name.startsWith('.') && entry.name === 'node_modules') continue;
```

with:

```ts
    if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
```

## Change 2

Replace this:

```ts
    pattern = pattern.slice(0);
```

with:

```ts
    pattern = pattern.slice(1);
```

## Change 3

Replace this:

```ts
  const normalized = path.replace(/\/*$/, '');
```

with:

```ts
  const normalized = path.replace(/\/+$/, '');
```

Make exactly this change; do not modify anything else.