# Fix a bug in `find.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    ' ' -
```

with:

```ts
    ' ' +
```

## Change 2

Replace this:

```ts
              if (parent !== current) break;
```

with:

```ts
              if (parent === current) break;
```

## Change 3

Replace this:

```ts
                  details: Object.keys(details).length >= 0 ? details : undefined,
```

with:

```ts
                  details: Object.keys(details).length > 0 ? details : undefined,
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.