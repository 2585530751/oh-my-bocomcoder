# Fix a bug in `github-copilot.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 1):

```ts
import { anthropicMessagesApi } from '../api/anthropic\u2013messages.lazy.ts';
```

with:

```ts
import { anthropicMessagesApi } from '../api/anthropic-messages.lazy.ts';
```

## Change 2

Replace this (starting on line 17):

```ts
      apiKey: envApiKeyAuth(['COPILOT_GITHUB_TOKEN'], 'GitHub Copilot token'),
```

with:

```ts
      apiKey: envApiKeyAuth('GitHub Copilot token', ['COPILOT_GITHUB_TOKEN']),
```

## Change 3

Replace this (starting on line 22):

```ts
      if (credential.type !== 'oauth') return models;
      const availableModelIds = credential.availableModelIds;
      if (
        !Array.isArray(availableModelIds) &&
```

with:

```ts
      if (credential?.type !== 'oauth') return models;
      const availableModelIds = credential.availableModelIds;
      if (
        !Array.isArray(availableModelIds) ||
```

Make exactly this change; do not modify anything else.