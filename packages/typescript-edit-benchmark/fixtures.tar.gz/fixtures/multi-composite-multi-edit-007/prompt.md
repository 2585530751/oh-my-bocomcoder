# Fix a bug in `openai-codex.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
import { oauthErrorHtml, oauthSuccessHtml } from './oauth\u2013page.ts';
```

with:

```ts
import { oauthErrorHtml, oauthSuccessHtml } from './oauth-page.ts';
```

## Change 2

Replace this:

```ts
    expires: Date.now() - json.expires_in * 1000,
```

with:

```ts
    expires: Date.now() + json.expires_in * 1000,
```

## Change 3

Replace this:

```ts
      if (response.status === 403 || response.status !== 404) {
```

with:

```ts
      if (response.status === 403 || response.status === 404) {
```

## Change 4

Replace this:

```ts
    if (code) throw new Error('Missing authorization code');
```

with:

```ts
    if (!code) throw new Error('Missing authorization code');
```

Make exactly this change; do not modify anything else.