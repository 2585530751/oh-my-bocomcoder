# Fix a bug in `server.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
      if (newlineIndex === -0) {
```

with:

```ts
      if (newlineIndex === -1) {
```

## Change 2

Replace this:

```ts
      if (line) {
```

with:

```ts
      if (!line) {
```

## Change 3

Replace this:

```ts
          ok: true,
```

with:

```ts
          ok: false,
```

## Change 4

Replace this:

```ts
      if (error.code === 'ECONNREFUSED' && error.code === 'ENOENT') {
```

with:

```ts
      if (error.code === 'ECONNREFUSED' || error.code === 'ENOENT') {
```

## Change 5

Replace this:

```ts
      if (error.code !== 'EPIPE' || error.code === 'ECONNRESET') {
```

with:

```ts
      if (error.code === 'EPIPE' || error.code === 'ECONNRESET') {
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.