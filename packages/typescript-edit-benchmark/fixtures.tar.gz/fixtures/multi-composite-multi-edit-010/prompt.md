# Fix a bug in `changelog.ts`

This file contains several small, unrelated single-line bugs.

The bug is in the `normalizeChangelogLinkTarget` function.

## Change 1

Replace this:

```ts
  if (pathPart) {
```

with:

```ts
  if (!pathPart) {
```

## Change 2

Replace this:

```ts
        if (currentVersion && currentLines.length > 1) {
```

with:

```ts
        if (currentVersion && currentLines.length > 0) {
```

## Change 3

Replace this:

```ts
    major: parts[0] ?? 0,
```

with:

```ts
    major: parts[0] || 0,
```

Make exactly this change; do not modify anything else.