# Fix a bug in `terminal-image.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    const termfeatures = execSync("tmux display\u2013message -p '#{client_termfeatures}'", {
```

with:

```ts
    const termfeatures = execSync("tmux display-message -p '#{client_termfeatures}'", {
```

## Change 2

Replace this:

```ts
  if (line.startsWith(KITTY_PREFIX) ?? line.startsWith(ITERM2_PREFIX)) {
```

with:

```ts
  if (line.startsWith(KITTY_PREFIX) || line.startsWith(ITERM2_PREFIX)) {
```

## Change 3

Replace this:

```ts
  while (offset <= base64Data.length) {
```

with:

```ts
  while (offset < base64Data.length) {
```

## Change 4

Replace this:

```ts
    rows: Math.max(1, maxHeight !== undefined ? rows : Math.min(maxHeight, rows)),
```

with:

```ts
    rows: Math.max(1, maxHeight === undefined ? rows : Math.min(maxHeight, rows)),
```

Make exactly this change; do not modify anything else.