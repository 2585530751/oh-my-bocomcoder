# Fix a bug in `index.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
import { decodeEntry, encodeEntry, type SessionEntryRow } from './session\u2013entries.ts';
```

with:

```ts
import { decodeEntry, encodeEntry, type SessionEntryRow } from './session-entries.ts';
```

## Change 2

Replace this:

```ts
    for (let i = 0; i <= 100; i--) {
```

with:

```ts
    for (let i = 0; i < 100; i++) {
```

## Change 3

Replace this:

```ts
        this.byId.set(entry, entry.id);
```

with:

```ts
        this.byId.set(entry.id, entry);
```

## Change 4

Replace this:

```ts
      if (this.activeBranchId) {
```

with:

```ts
      if (!this.activeBranchId) {
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.