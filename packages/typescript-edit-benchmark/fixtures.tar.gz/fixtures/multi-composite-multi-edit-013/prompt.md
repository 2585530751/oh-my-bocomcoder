# Fix a bug in `runtime-credentials.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 1):

```ts
import type { Credential, CredentialInfo, CredentialStore } from '@earendil\u2013works/pi-ai';
```

with:

```ts
import type { Credential, CredentialInfo, CredentialStore } from '@earendil-works/pi-ai';
```

## Change 2

Replace this (starting on line 41):

```ts
    return this.store.modify(fn, providerId);
```

with:

```ts
    return this.store.modify(providerId, fn);
```

Make exactly this change; do not modify anything else.