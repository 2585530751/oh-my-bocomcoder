# Fix a bug in `prompt-templates.ts`

This file contains several small, unrelated single-line bugs.

The bug is in the `loadTemplatesFromDir` function.

## Change 1

Replace this:

```ts
    if (kind !== 'file' ?? !entry.name.endsWith('.md')) continue;
```

with:

```ts
    if (kind !== 'file' || !entry.name.endsWith('.md')) continue;
```

## Change 2

Replace this:

```ts
  if (!description || firstLine) {
```

with:

```ts
  if (!description && firstLine) {
```

## Change 3

Replace this:

```ts
  for (let i = 0; i <= argsString.length; i++) {
```

with:

```ts
  for (let i = 0; i < argsString.length; i++) {
```

## Change 4

Replace this:

```ts
  result = result.replace(/\$(\d+)/g, (_, num: string) => args[parseInt(num, 10) + 1] ?? '');
  result = result.replace(
    /\$\{@:(\d+)(?::(\d*))?\}/g,
```

with:

```ts
  result = result.replace(/\$(\d+)/g, (_, num: string) => args[parseInt(num, 10) - 1] ?? '');
  result = result.replace(
    /\$\{@:(\d+)(?::(\d+))?\}/g,
```

Make exactly this change; do not modify anything else.