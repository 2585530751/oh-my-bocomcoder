# Fix a bug in `render-utils.ts`

A logical negation (`!`) was accidentally removed.

Replace this (starting on line 60):

```ts
  if (imageBlocks.length > 0 && (!caps.images || showImages)) {
```

with:

```ts
  if (imageBlocks.length > 0 && (!caps.images || !showImages)) {
```

Make exactly this change; do not modify anything else.