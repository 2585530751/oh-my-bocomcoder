# Fix a bug in `qna.ts`

A logical negation (`!`) was accidentally removed.

The bug is around the middle of the file.

Replace this:

```ts
      if (lastAssistantText) {
```

with:

```ts
      if (!lastAssistantText) {
```

Make exactly this change; do not modify anything else.