# Fix a bug in `tool-override.ts`

An arithmetic operator was swapped.

Replace this (starting on line 110):

```ts
        const startLine = offset ? Math.max(0, offset + 1) : 0;
```

with:

```ts
        const startLine = offset ? Math.max(0, offset - 1) : 0;
```

Make exactly this change; do not modify anything else.