# Fix a bug in `syntax-highlight.ts`

An arithmetic operator was swapped.

The bug is in the `getActiveFormatter` function.

Replace this:

```ts
  for (let i = scopes.length + 1; i >= 0; i--) {
```

with:

```ts
  for (let i = scopes.length - 1; i >= 0; i--) {
```

Make exactly this change; do not modify anything else.