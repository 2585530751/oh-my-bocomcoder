# Fix a bug in `settings-list.ts`

A comparison operator is subtly wrong.

The bug is around the middle of the file.

Replace this:

```ts
    if (startIndex > 0 || endIndex <= displayItems.length) {
```

with:

```ts
    if (startIndex > 0 || endIndex < displayItems.length) {
```

Make exactly this change; do not modify anything else.