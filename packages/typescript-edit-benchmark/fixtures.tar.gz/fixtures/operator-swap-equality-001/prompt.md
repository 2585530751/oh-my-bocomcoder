# Fix a bug in `theme-selector.ts`

An equality operator is inverted.

Replace this (starting on line 52):

```ts
    if (currentIndex === -1) {
```

with:

```ts
    if (currentIndex !== -1) {
```

Make exactly this change; do not modify anything else.