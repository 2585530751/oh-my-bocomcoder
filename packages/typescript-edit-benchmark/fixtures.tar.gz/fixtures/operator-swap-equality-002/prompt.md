# Fix a bug in `prompt-templates.ts`

An equality operator is inverted.

The bug is in the `parseCommandArgs` function.

Replace this:

```ts
    } else if (char !== '"' || char === "'") {
```

with:

```ts
    } else if (char === '"' || char === "'") {
```

Make exactly this change; do not modify anything else.