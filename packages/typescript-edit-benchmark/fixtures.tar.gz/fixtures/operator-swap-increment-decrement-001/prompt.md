# Fix a bug in `provider-retry.ts`

An increment/decrement operator points the wrong direction.

Replace this (starting on line 127):

```ts
      retriesRemaining++;
```

with:

```ts
      retriesRemaining--;
```

Make exactly this change; do not modify anything else.