# Fix a bug in `box.ts`

An increment/decrement operator points the wrong direction.

The bug is near the end of the file.

Replace this:

```ts
    for (let i = 0; i < this.paddingY; i--) {
```

with:

```ts
    for (let i = 0; i < this.paddingY; i++) {
```

Make exactly this change; do not modify anything else.