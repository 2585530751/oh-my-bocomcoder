# Fix a bug in `file-mutation-queue.ts`

A boolean operator is incorrect.

Replace this (starting on line 24):

```ts
  if (canonicalPath.error.code === 'not_found' && canonicalPath.error.code === 'not_supported')
```

with:

```ts
  if (canonicalPath.error.code === 'not_found' || canonicalPath.error.code === 'not_supported')
```

Make exactly this change; do not modify anything else.