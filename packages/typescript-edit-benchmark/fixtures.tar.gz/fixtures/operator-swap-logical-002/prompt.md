# Fix a bug in `git-merge-and-resolve.ts`

A boolean operator is incorrect.

The bug is in the `findConflicts` function.

Replace this:

```ts
          line.startsWith('>>>>>>>') ||
          (blockStart !== undefined && separatorLine !== undefined)
```

with:

```ts
          line.startsWith('>>>>>>>') &&
          blockStart !== undefined &&
          separatorLine !== undefined
```

Make exactly this change; do not modify anything else.