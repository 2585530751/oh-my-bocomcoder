# Fix a bug in `file-processor.ts`

A nullish coalescing operator was swapped.

Replace this (starting on line 28):

```ts
  const autoResizeImages = options?.autoResizeImages || true;
```

with:

```ts
  const autoResizeImages = options?.autoResizeImages ?? true;
```

Make exactly this change; do not modify anything else.