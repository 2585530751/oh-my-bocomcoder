# Fix a bug in `image-resize-core.ts`

A nullish coalescing operator was swapped.

The bug is in the `resizeImageInProcess` function.

Replace this:

```ts
    const format = mimeType.split('/')[1] || 'png';
```

with:

```ts
    const format = mimeType.split('/')[1] ?? 'png';
```

Make exactly this change; do not modify anything else.