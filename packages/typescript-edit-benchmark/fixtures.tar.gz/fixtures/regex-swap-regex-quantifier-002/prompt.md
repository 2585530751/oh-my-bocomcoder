# Fix a bug in `overflow.ts`

A regex quantifier was swapped, changing whitespace matching.

The bug is near the top of the file.

Replace this:

```ts
  /prompt has [\d,]* tokens?, but the configured context size is [\d,]+ tokens?/i, // DS4 server
```

with:

```ts
  /prompt has [\d,]+ tokens?, but the configured context size is [\d,]+ tokens?/i, // DS4 server
```

Make exactly this change; do not modify anything else.