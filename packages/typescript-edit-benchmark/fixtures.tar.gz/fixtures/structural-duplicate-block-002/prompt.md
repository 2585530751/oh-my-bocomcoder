# Fix a bug in `model-registry.ts`

The block starting with `if (typeof providerOrName === 'string') {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 130:

```ts
    }
```

Make exactly this change; do not modify anything else.