# Fix a bug in `space-invaders.ts`

The block starting with `for (let x = 0; x < GAME_WIDTH; x++) {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 487:

```ts
      }
```

Make exactly this change; do not modify anything else.