# Fix a bug in `keybindings.ts`

The block starting with `for (const key of keyList) {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 151:

```ts
  }
```

Make exactly this change; do not modify anything else.