# Fix a bug in `credential-print.ts`

The block starting with `for (const model of models) {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 166:

```ts
  if (credentials.length === 1) return credentials[0].value;
```

Make exactly this change; do not modify anything else.