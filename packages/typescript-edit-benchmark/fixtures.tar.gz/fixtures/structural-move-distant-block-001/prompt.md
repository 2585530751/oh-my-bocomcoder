# Fix a bug in `edit.ts`

The block starting with `const legacy = args as LegacyEditToolInput;` was moved to the wrong place — it currently sits after `const args = input as Record<string, unknown>;`. Move it back so it comes directly before `return { ...rest, edits } as EditToolInput;`.

After the fix, the affected regions must read exactly:

Around line 50:

```ts
  const args = input as Record<string, unknown>;
  if (typeof args.edits === 'string') {
```

Around line 62:

```ts
    } catch {}
  }

  const legacy = args as LegacyEditToolInput;
  if (typeof legacy.oldText !== 'string' || typeof legacy.newText !== 'string')
    return args as EditToolInput;
  const edits = Array.isArray(legacy.edits) ? [...legacy.edits] : [];
  edits.push({ oldText: legacy.oldText, newText: legacy.newText });
  const { oldText: _oldText, newText: _newText, ...rest } = legacy;
```

Make exactly this change; do not modify anything else.