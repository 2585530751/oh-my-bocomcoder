# Fix a bug in `child-process.ts`

The block starting with `const onData = () => {` was moved to the wrong place — it currently sits after `child.once('close', onClose);`. Move it back so it comes directly before `const onStdoutEnd = () => {`.

After the fix, the affected regions must read exactly:

Around line 95:

```ts
    const onData = () => {
      // Output is still arriving after exit; defer finalizing so we don't
      // destroy the stream mid-write and truncate the tail.
      if (exited && !settled) armIdleTimer();
    };

    const onStdoutEnd = () => {
```

Around line 131:

```ts
    child.once('close', onClose);
```

Make exactly this change; do not modify anything else.