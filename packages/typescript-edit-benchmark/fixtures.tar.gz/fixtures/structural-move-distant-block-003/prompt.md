# Fix a bug in `index.ts`

The block starting with `const model = quantization ? `${details.id}:${quantization}` : details.id;` was moved to the wrong place — it currently sits after `let quantization = parsed.quantization;`. Move it back so it comes directly before `ctx.ui.notify(`Downloaded ${model}`);`.

After the fix, the affected regions must read exactly:

Around line 158:

```ts
    let quantization = parsed.quantization;
    if (!quantization && details.quantizations.length > 0) {
```

Around line 185:

```ts
      if (!quantization) return;
    }
    const model = quantization ? `${details.id}:${quantization}` : details.id;
    const result = await runWithProgress(ui, {
      title: 'Downloading model',
      model,
      initialMessage: 'Starting…',
      cancelTitle: 'Stop download?',
      cancelMessage: model,
      run: (signal, update) => client.downloadAndWait(model, update, signal),
      cancel: () => client.unload(model),
    });
    if (result.cancelled) return;
    await syncCatalog(ctx, client, result.value);
```

Make exactly this change; do not modify anything else.