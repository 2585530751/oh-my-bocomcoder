# Fix a bug in `openai-responses.ts`

The block starting with `if (nextParams !== undefined) {` was moved to the wrong place — it currently sits after `stream.push({ type: 'done', reason: output.stopReason, message: output });`. Move it back so it comes directly before `const requestOptions = {`.

After the fix, the affected regions must read exactly:

Around line 161:

```ts
      const nextParams = await options?.onPayload?.(params, model);
      if (nextParams !== undefined) {
        params = nextParams as ResponseCreateParamsStreaming;
      }
```

Around line 199:

```ts
      stream.push({ type: 'done', reason: output.stopReason, message: output });
```

Make exactly this change; do not modify anything else.