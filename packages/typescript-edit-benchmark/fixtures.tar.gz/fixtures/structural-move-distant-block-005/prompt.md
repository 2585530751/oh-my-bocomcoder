# Fix a bug in `08-prompt-templates.ts`

The block starting with `const deployTemplate: PromptTemplate = {` was moved to the wrong place — it currently sits after `console.log('Discovered prompt templates:');`. Move it back so it comes directly before `const loader = new DefaultResourceLoader({`.

After the fix, the affected regions must read exactly:

Around line 16:

```ts
// Define custom templates
const deployTemplate: PromptTemplate = {
  name: 'deploy',
  description: 'Deploy the application',
  filePath: '/virtual/prompts/deploy.md',
  sourceInfo: createSyntheticSourceInfo('/virtual/prompts/deploy.md', { source: 'sdk' }),
  content: `# Deploy Instructions

1. Build: npm run build
2. Test: npm test
3. Deploy: npm run deploy`,
};

const loader = new DefaultResourceLoader({
```

Around line 29:

```ts
console.log('Discovered prompt templates:');
```

Make exactly this change; do not modify anything else.