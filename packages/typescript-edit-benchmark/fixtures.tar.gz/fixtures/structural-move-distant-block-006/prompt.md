# Fix a bug in `messages.ts`

The block starting with `if (msg.output) {` was moved to the wrong place — it currently sits after `return text;`. Move it back so it comes directly before `if (msg.cancelled) {`.

After the fix, the affected regions must read exactly:

Around line 83:

```ts
  let text = `Ran \`${msg.command}\`\n`;
  if (msg.output) {
    text += `\`\`\`\n${msg.output}\n\`\`\``;
  } else {
    text += '(no output)';
  }
```

Around line 92:

```ts
  return text;
```

Make exactly this change; do not modify anything else.