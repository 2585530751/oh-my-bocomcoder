# Fix a bug in `keybindings.ts`

The block starting with `export interface Keybindings {` was moved to the wrong place — it currently sits after `let globalKeybindings: KeybindingsManager | null = null;`. Move it back so it comes directly before `export type Keybinding = keyof Keybindings;`.

After the fix, the affected regions must read exactly:

Around line 6:

```ts
 */
export interface Keybindings {
  // Editor navigation and editing
  'tui.editor.cursorUp': true;
  'tui.editor.cursorDown': true;
  'tui.editor.cursorLeft': true;
  'tui.editor.cursorRight': true;
  'tui.editor.cursorWordLeft': true;
  'tui.editor.cursorWordRight': true;
  'tui.editor.cursorLineStart': true;
  'tui.editor.cursorLineEnd': true;
  'tui.editor.jumpForward': true;
  'tui.editor.jumpBackward': true;
  'tui.editor.pageUp': true;
  'tui.editor.pageDown': true;
  'tui.editor.deleteCharBackward': true;
  'tui.editor.deleteCharForward': true;
  'tui.editor.deleteWordBackward': true;
  'tui.editor.deleteWordForward': true;
  'tui.editor.deleteToLineStart': true;
  'tui.editor.deleteToLineEnd': true;
  'tui.editor.yank': true;
  'tui.editor.yankPop': true;
  'tui.editor.undo': true;
  // Generic input actions
  'tui.input.newLine': true;
  'tui.input.submit': true;
  'tui.input.tab': true;
  'tui.input.copy': true;
  // Generic selection actions
  'tui.select.up': true;
  'tui.select.down': true;
  'tui.select.pageUp': true;
  'tui.select.pageDown': true;
  'tui.select.confirm': true;
  'tui.select.cancel': true;
}

export type Keybinding = keyof Keybindings;
```

Around line 202:

```ts
export function setKeybindings(keybindings: KeybindingsManager): void {
```

Make exactly this change; do not modify anything else.