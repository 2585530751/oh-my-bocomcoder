# Fix a bug in `compat.ts`

The block starting with `function wrapStream<TApi extends Api, TOptions extends StreamOptions>(` was moved to the wrong place — it currently sits after `const compatModels = builtinModels();`. Move it back so it comes directly before `function wrapStreamSimple<TApi extends Api>(`.

After the fix, the affected regions must read exactly:

Around line 114:

```ts
function wrapStream<TApi extends Api, TOptions extends StreamOptions>(
  api: TApi,
  stream: StreamFunction<TApi, TOptions>,
): ApiStreamFunction {
  return (model, context, options) => {
    if (model.api !== api) {
      throw new Error(`Mismatched api: ${model.api} expected ${api}`);
    }
    return stream(model as Model<TApi>, context, options as TOptions);
  };
}

function wrapStreamSimple<TApi extends Api>(
```

Around line 220:

```ts
const compatModels = builtinModels();
```

Make exactly this change; do not modify anything else.