# Fix a bug in `simple-options.ts`

The block starting with `const defaultBudgets: ThinkingBudgets = {` was moved to the wrong place — it currently sits after `return { maxTokens, thinkingBudget };`. Move it back so it comes directly before `const budgets = { ...defaultBudgets, ...customBudgets };`.

After the fix, the affected regions must read exactly:

Around line 65:

```ts
): { maxTokens: number; thinkingBudget: number } {
  const defaultBudgets: ThinkingBudgets = {
    minimal: 1024,
    low: 2048,
    medium: 8192,
    high: 16384,
  };
```

Around line 80:

```ts
  return { maxTokens, thinkingBudget };
```

Make exactly this change; do not modify anything else.