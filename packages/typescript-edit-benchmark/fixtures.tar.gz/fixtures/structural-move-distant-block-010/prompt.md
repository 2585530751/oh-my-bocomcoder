# Fix a bug in `memory-storage.ts`

The block starting with `const usage =` was moved to the wrong place — it currently sits after `totalTokens += usage.input + usage.output + usage.cacheRead + usage.cacheWrite;`. Move it back so it comes directly before `if (`.

After the fix, the affected regions must read exactly:

Around line 132:

```ts
        messageCount += 1;
      }
      const usage =
        entry.type === 'message'
          ? entry.message.role === 'assistant'
            ? entry.message.usage
            : undefined
          : entry.type === 'compaction' || entry.type === 'branch_summary'
            ? entry.usage
            : undefined;
```

Around line 146:

```ts
      totalTokens += usage.input + usage.output + usage.cacheRead + usage.cacheWrite;
```

Make exactly this change; do not modify anything else.