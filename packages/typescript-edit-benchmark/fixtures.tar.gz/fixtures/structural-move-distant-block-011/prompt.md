# Fix a bug in `test.ts`

The block starting with `const context: Context = {` was moved to the wrong place — it currently sits after `// Create model`. Move it back so it comes directly before `for await (const event of stream) {`.

After the fix, the affected regions must read exactly:

Around line 52:

```ts
  // Create model
  const model: Model<Api> = {
```

Around line 78:

```ts
  const context: Context = {
    messages: [{ role: 'user', content: 'Say hello in exactly 3 words.', timestamp: Date.now() }],
  };

  console.log(`Model: ${model.id}, Backend: ${cfg.backend}, Thinking: ${useThinking}`);

  const stream = streamSimple(model, context, {
    apiKey: gitlabCred.access,
    maxTokens: 100,
    reasoning: useThinking ? 'low' : undefined,
  });

  for await (const event of stream) {
```

Make exactly this change; do not modify anything else.