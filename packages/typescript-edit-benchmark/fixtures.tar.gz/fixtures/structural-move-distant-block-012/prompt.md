# Fix a bug in `space-invaders.ts`

The block starting with `if (this.paused) {` was moved to the wrong place — it currently sits after `return lines;`. Move it back so it comes directly before `lines.push(this.padLine(boxLine(footer), width));`.

After the fix, the affected regions must read exactly:

Around line 495:

```ts
    let footer: string;
    if (this.paused) {
      footer = `${yellow(bold('PAUSED'))} Press any key to continue, ${bold('Q')} to quit`;
    } else if (this.state.gameOver) {
      footer = `${red(bold('GAME OVER!'))} Press ${bold('R')} to restart, ${bold('Q')} to quit`;
    } else if (this.state.victory) {
      footer = `${green(bold('VICTORY!'))} Press ${bold('R')} for level ${this.state.level + 1}, ${bold('Q')} to quit`;
    } else {
      footer = `←→ or AD to move, ${bold('SPACE')}/F to fire, ${bold('ESC')} pause, ${bold('Q')} quit`;
    }
```

Around line 505:

```ts
    return lines;
```

Make exactly this change; do not modify anything else.