# Fix a bug in `config.ts`

The block starting with `function makeSelfUpdateCommand(` was moved to the wrong place — it currently sits after `export const VERSION: string = pkg.version || '0.0.0';`. Move it back so it comes directly before `function makeSelfUpdateCommandStep(command: string, args: string[]): SelfUpdateCommandStep {`.

After the fix, the affected regions must read exactly:

Around line 55:

```ts
function makeSelfUpdateCommand(
  installStep: SelfUpdateCommandStep,
  uninstallStep?: SelfUpdateCommandStep,
): SelfUpdateCommand {
  if (!uninstallStep) return installStep;
  return {
    ...installStep,
    display: `${uninstallStep.display} && ${installStep.display}`,
    steps: [uninstallStep, installStep],
  };
}

function makeSelfUpdateCommandStep(command: string, args: string[]): SelfUpdateCommandStep {
```

Around line 530:

```ts
// e.g., PI_CODING_AGENT_DIR or TAU_CODING_AGENT_DIR
```

Make exactly this change; do not modify anything else.