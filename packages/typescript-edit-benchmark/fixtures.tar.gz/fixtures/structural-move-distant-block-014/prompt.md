# Fix a bug in `tools.ts`

The block starting with `container.addChild(` was moved to the wrong place — it currently sits after `return component;`. Move it back so it comes directly before `const settingsList = new SettingsList(`.

After the fix, the affected regions must read exactly:

Around line 87:

```ts
        const container = new Container();
        container.addChild(
          new (class {
            render(_width: number) {
              return [theme.fg('accent', theme.bold('Tool Configuration')), ''];
            }
            invalidate() {}
          })(),
        );

        const settingsList = new SettingsList(
```

Around line 123:

```ts
        return component;
```

Make exactly this change; do not modify anything else.