# Fix a bug in `messages.ts`

In this file's `switch`, the value in `case 'user':` must be handled exactly like the case after it: add a fall-through `case 'user':` label directly before `case 'assistant':`.

After the fix, the affected region must read exactly:

Around line 169:

```ts
          };
        case 'user':
        case 'assistant':
```

Make exactly this change; do not modify anything else.