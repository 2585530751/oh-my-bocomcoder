# Fix a bug in `messages.ts`

In this file's `switch`, the value in `case 'assistant':` must be handled exactly like the case after it: add a fall-through `case 'assistant':` label directly before `case 'toolResult':`.

After the fix, the affected region must read exactly:

Around line 199:

```ts
        case 'user':
        case 'assistant':
        case 'toolResult':
```

Make exactly this change; do not modify anything else.