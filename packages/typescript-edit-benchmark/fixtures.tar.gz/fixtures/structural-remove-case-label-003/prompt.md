# Fix a bug in `index.ts`

In this file's `switch`, the value in `case 'pause_turn':` must be handled exactly like the case after it: add a fall-through `case 'pause_turn':` label directly before `case 'stop_sequence':`.

After the fix, the affected region must read exactly:

Around line 328:

```ts
    case 'end_turn':
    case 'pause_turn':
    case 'stop_sequence':
```

Make exactly this change; do not modify anything else.