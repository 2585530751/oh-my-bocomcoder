# Fix a bug in `session-materialized.ts`

In this file's `switch`, the value in `case 'active_tools_change':` must be handled exactly like the case after it: add a fall-through `case 'active_tools_change':` label directly before `case 'branch_summary':`.

After the fix, the affected region must read exactly:

Around line 370:

```ts
      return [];
    case 'active_tools_change':
    case 'branch_summary':
```

Make exactly this change; do not modify anything else.