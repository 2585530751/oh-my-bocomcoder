# Fix a bug in `branch-summarization.ts`

In this file's `switch`, the value in `case 'model_change':` must be handled exactly like the case after it: add a fall-through `case 'model_change':` label directly before `case 'active_tools_change':`.

After the fix, the affected region must read exactly:

Around line 131:

```ts
    case 'thinking_level_change':
    case 'model_change':
    case 'active_tools_change':
```

Make exactly this change; do not modify anything else.