# Fix a bug in `openai-responses-shared.ts`

In this file's `switch`, the value in `case 'in_progress':` must be handled exactly like the case after it: add a fall-through `case 'in_progress':` label directly before `case 'queued':`.

After the fix, the affected region must read exactly:

Around line 797:

```ts
    // These two are wonky ...
    case 'in_progress':
    case 'queued':
```

Make exactly this change; do not modify anything else.