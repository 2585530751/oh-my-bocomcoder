# Fix a bug in `session-materialized.ts`

In this file's `switch`, the value in `case 'compaction':` must be handled exactly like the case after it: add a fall-through `case 'compaction':` label directly before `case 'branch_summary': {`.

After the fix, the affected region must read exactly:

Around line 186:

```ts
    }
    case 'compaction':
    case 'branch_summary': {
```

Make exactly this change; do not modify anything else.