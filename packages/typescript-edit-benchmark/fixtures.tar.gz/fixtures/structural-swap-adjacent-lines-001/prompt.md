# Fix a bug in `provider-env.ts`

Two adjacent statements are in the wrong order: `import type { ProviderEnv } from '../types.ts';` belongs before `let procEnvCache: Map<string, string> | null = null;`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 1:

```ts
import type { ProviderEnv } from '../types.ts';

let procEnvCache: Map<string, string> | null = null;
```

Make exactly this change; do not modify anything else.