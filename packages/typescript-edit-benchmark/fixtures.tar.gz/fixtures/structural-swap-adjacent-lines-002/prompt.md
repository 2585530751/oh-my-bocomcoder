# Fix a bug in `handler.ts`

Two adjacent statements are in the wrong order: `request: RpcRequest,` belongs before `request: RpcStreamRequest,`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 59:

```ts
  request: RpcRequest,
): Promise<RpcBridgeResponse | ErrorResponse>;
export async function handleIpcRequest(
  request: RpcStreamRequest,
): Promise<RpcReadyResponse | ErrorResponse>;
```

Make exactly this change; do not modify anything else.