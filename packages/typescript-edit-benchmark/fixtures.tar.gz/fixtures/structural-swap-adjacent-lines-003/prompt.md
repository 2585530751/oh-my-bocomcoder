# Fix a bug in `autocomplete.ts`

Two adjacent statements are in the wrong order: `this.commands = commands;` belongs before `this.basePath = basePath;`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 291:

```ts
    this.commands = commands;
    this.basePath = basePath;
```

Make exactly this change; do not modify anything else.