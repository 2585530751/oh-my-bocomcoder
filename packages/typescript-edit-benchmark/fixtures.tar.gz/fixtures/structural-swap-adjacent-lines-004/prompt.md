# Fix a bug in `keybindings.ts`

Two adjacent statements are in the wrong order: `const claimants = userClaims.get(key) ?? new Set<Keybinding>();` belongs before `claimants.add(keybinding as Keybinding);`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 175:

```ts
        const claimants = userClaims.get(key) ?? new Set<Keybinding>();
        claimants.add(keybinding as Keybinding);
```

Make exactly this change; do not modify anything else.