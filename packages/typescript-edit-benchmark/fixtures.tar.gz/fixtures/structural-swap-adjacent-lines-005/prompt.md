# Fix a bug in `abort-signals.ts`

Two adjacent statements are in the wrong order: `const listener = () => abort(signal);` belongs before `signal.addEventListener('abort', listener, { once: true });`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 30:

```ts
    const listener = () => abort(signal);
    signal.addEventListener('abort', listener, { once: true });
```

Make exactly this change; do not modify anything else.