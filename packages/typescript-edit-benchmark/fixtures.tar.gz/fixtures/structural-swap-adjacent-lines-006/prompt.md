# Fix a bug in `doom-engine.ts`

Two adjacent statements are in the wrong order: `this._width = this.module._DG_GetScreenWidth();` belongs before `this._height = this.module._DG_GetScreenHeight();`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 110:

```ts
    this._width = this.module._DG_GetScreenWidth();
    this._height = this.module._DG_GetScreenHeight();
```

Make exactly this change; do not modify anything else.