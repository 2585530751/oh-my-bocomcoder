# Fix a bug in `mime.ts`

The branch bodies of `} else if (dibHeaderSize >= 40 && dibHeaderSize <= 124) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 76:

```ts
  } else if (dibHeaderSize >= 40 && dibHeaderSize <= 124) {
```

Around line 81:

```ts
    bitsPerPixel = readUint16LE(buffer, 28);
  } else {
    return false;
```

Make exactly this change; do not modify anything else.