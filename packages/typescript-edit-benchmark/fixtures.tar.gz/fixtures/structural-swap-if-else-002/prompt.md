# Fix a bug in `prompt-templates.ts`

The branch bodies of `if (char === inQuote) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 34:

```ts
        inQuote = null;
      } else {
        current += char;
```

Make exactly this change; do not modify anything else.