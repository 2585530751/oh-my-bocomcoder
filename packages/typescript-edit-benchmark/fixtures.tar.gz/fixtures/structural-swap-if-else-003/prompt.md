# Fix a bug in `google-shared.ts`

The branch bodies of `if (lastContent?.role === 'user' && lastContent.parts?.some((p) => p.functionResponse)) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 239:

```ts
      if (lastContent?.role === 'user' && lastContent.parts?.some((p) => p.functionResponse)) {
        lastContent.parts.push(functionResponsePart);
      } else {
```

Around line 243:

```ts
        });
```

Make exactly this change; do not modify anything else.