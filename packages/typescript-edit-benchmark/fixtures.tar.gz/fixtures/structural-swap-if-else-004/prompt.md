# Fix a bug in `armin.ts`

The branch bodies of `if (targetRow >= 0 && drop.y >= targetRow) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 288:

```ts
          // Settle
          drop.settled = DISPLAY_HEIGHT - targetRow;
          drop.y = -Math.floor(Math.random() * 5) - 1;
        } else {
          // Still falling
          this.currentGrid[drop.y][x] = '▓';
```

Make exactly this change; do not modify anything else.