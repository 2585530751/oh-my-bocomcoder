# Fix a bug in `custom-message.ts`

The branch bodies of `if (typeof this.message.content === 'string') {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 98:

```ts
    if (typeof this.message.content === 'string') {
      text = this.message.content;
    } else {
```

Around line 102:

```ts
        .join('\n');
```

Make exactly this change; do not modify anything else.