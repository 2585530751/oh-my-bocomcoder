# Fix a bug in `models-store.ts`

Two adjacent blocks are in the wrong order: the block starting with `export interface ProviderModelsStore {` belongs before the block starting with `export class InMemoryModelsStore implements ModelsStore {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 23:

```ts
/** ModelsStore scoped to one provider. Providers cannot access other providers' catalogs. */
export interface ProviderModelsStore {
  read(): Promise<ModelsStoreEntry | undefined>;
  write(entry: ModelsStoreEntry): Promise<void>;
  delete(): Promise<void>;
}

export class InMemoryModelsStore implements ModelsStore {
```

Around line 39:

```ts
}
```

Make exactly this change; do not modify anything else.