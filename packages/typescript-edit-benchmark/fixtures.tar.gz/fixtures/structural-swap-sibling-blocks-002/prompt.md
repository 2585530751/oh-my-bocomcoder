# Fix a bug in `truncated-tool.ts`

Two adjacent blocks are in the wrong order: the block starting with `const RgParams = Type.Object({` belongs before the block starting with `interface RgDetails {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 33:

```ts
const RgParams = Type.Object({
  pattern: Type.String({ description: 'Search pattern (regex)' }),
  path: Type.Optional(
    Type.String({ description: 'Directory to search (default: current directory)' }),
  ),
  glob: Type.Optional(Type.String({ description: "File glob pattern, e.g. '*.ts'" })),
});

interface RgDetails {
```

Around line 42:

```ts
export default function (pi: ExtensionAPI) {
```

Make exactly this change; do not modify anything else.