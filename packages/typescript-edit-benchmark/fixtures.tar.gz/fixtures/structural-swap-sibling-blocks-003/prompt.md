# Fix a bug in `test-theme-colors.ts`

Two adjacent blocks are in the wrong order: the block starting with `function cmdTest(filePath: string): void {` belongs before the block starting with `function cmdTheme(themeName: string): void {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 125:

```ts
function cmdContrast(targetContrast: number): void {
```

Around line 181:

```ts
function cmdTest(filePath: string): void {
  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
  }

  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  const vars = data.vars || data;

  console.log(`\n=== Testing ${filePath} ===\n`);

  for (const [name, hex] of Object.entries(vars as Record<string, string>)) {
    if (!hex.startsWith('#')) continue;
    const rgb = hexToRgb(hex);
    const vsWhite = getContrast(rgb, 1.0);
    const vsBlack = getContrast(rgb, 0.0);
    const passW = vsWhite >= 4.5 ? 'AA' : vsWhite >= 3.0 ? 'AA-lg' : 'FAIL';
    const passB = vsBlack >= 4.5 ? 'AA' : vsBlack >= 3.0 ? 'AA-lg' : 'FAIL';
    console.log(
      `${name.padEnd(14)} ${fgAnsi(hex)}Sample text${reset}  ${hex}  white: ${vsWhite.toFixed(2)}:1 ${passW.padEnd(5)}  black: ${vsBlack.toFixed(2)}:1 ${passB}`,
    );
  }
}

function cmdTheme(themeName: string): void {
```

Make exactly this change; do not modify anything else.