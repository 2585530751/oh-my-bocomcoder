# Fix a bug in `openai-responses.ts`

Two adjacent blocks are in the wrong order: the block starting with `function getPromptCacheRetention(` belongs before the block starting with `function formatOpenAIResponsesError(error: unknown): string {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 80:

```ts
function getCompat(model: Model<'openai-responses'>): Required<OpenAIResponsesCompat> {
```

Around line 100:

```ts
function getPromptCacheRetention(
  compat: Required<OpenAIResponsesCompat>,
  cacheRetention: CacheRetention,
): '24h' | undefined {
  return cacheRetention === 'long' && compat.supportsLongCacheRetention ? '24h' : undefined;
}

function formatOpenAIResponsesError(error: unknown): string {
```

Make exactly this change; do not modify anything else.