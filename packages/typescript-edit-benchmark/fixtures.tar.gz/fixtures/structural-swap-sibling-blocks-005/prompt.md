# Fix a bug in `mac-system-theme.ts`

Two adjacent blocks are in the wrong order: the block starting with `async function isDarkMode(): Promise<boolean> {` belongs before the block starting with `export default function (pi: ExtensionAPI) {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 14:

```ts
async function isDarkMode(): Promise<boolean> {
  try {
    const { stdout } = await execAsync(
      'osascript -e \'tell application "System Events" to tell appearance preferences to return dark mode\'',
    );
    return stdout.trim() === 'true';
  } catch {
    return false;
  }
}

export default function (pi: ExtensionAPI) {
```

Around line 36:

```ts
}
```

Make exactly this change; do not modify anything else.