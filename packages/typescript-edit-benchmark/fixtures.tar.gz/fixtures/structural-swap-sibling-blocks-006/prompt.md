# Fix a bug in `protocol.ts`

Two adjacent blocks are in the wrong order: the block starting with `export interface RpcStreamRequest {` belongs before the block starting with `export interface RequestMap {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 38:

```ts
export interface RpcStreamRequest {
  type: 'rpc_stream';
  instanceId: string;
}

export interface RequestMap {
```

Around line 47:

```ts
export type ServerRequest = RequestMap[keyof RequestMap];
```

Make exactly this change; do not modify anything else.