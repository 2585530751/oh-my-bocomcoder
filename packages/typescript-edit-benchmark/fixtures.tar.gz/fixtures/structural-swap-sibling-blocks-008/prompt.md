# Fix a bug in `index.ts`

Two adjacent blocks are in the wrong order: the block starting with `const unloadModel = async (` belongs before the block starting with `const downloadModel = async (`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 126:

```ts
  const unloadModel = async (
    ctx: ExtensionCommandContext,
    ui: LlamaUi,
    client: LlamaClient,
    model: LlamaModelInfo,
  ): Promise<void> => {
    if (!(await ui.confirm('Unload model?', model.id))) return;
    await client.unloadAndWait(model.id);
    await syncCatalog(ctx, client);
    ctx.ui.notify(`Unloaded ${model.id}`);
  };

  const downloadModel = async (
```

Around line 177:

```ts
  pi.registerCommand('llama', {
```

Make exactly this change; do not modify anything else.