# Fix a bug in `oauth.ts`

Two adjacent blocks are in the wrong order: the block starting with `type OAuthCredentialEntry = {` belongs before the block starting with `type AuthCredential = ApiKeyCredential | OAuthCredentialEntry;`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 16:

```ts
type ApiKeyCredential = {
```

Around line 25:

```ts
type OAuthCredentialEntry = {
  type: 'oauth';
} & OAuthCredentials;

type AuthCredential = ApiKeyCredential | OAuthCredentialEntry;
```

Make exactly this change; do not modify anything else.