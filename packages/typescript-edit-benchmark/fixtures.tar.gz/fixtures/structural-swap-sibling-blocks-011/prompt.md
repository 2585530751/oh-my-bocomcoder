# Fix a bug in `space-invaders.ts`

Two adjacent blocks are in the wrong order: the block starting with `function createAliens(): Alien[] {` belongs before the block starting with `function createInitialState(highScore = 0, level = 1): GameState {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 56:

```ts
function createShields(): Shield[] {
```

Around line 88:

```ts
function createAliens(): Alien[] {
  const aliens: Alien[] = [];
  for (let row = 0; row < ALIEN_ROWS; row++) {
    const type = row === 0 ? 2 : row < 3 ? 1 : 0;
    for (let col = 0; col < ALIEN_COLS; col++) {
      aliens.push({
        x: 4 + col * 5,
        y: ALIEN_START_Y + row * 2,
        type,
        alive: true,
      });
    }
  }
  return aliens;
}

function createInitialState(highScore = 0, level = 1): GameState {
```

Make exactly this change; do not modify anything else.