# Fix a bug in `radius.ts`

Two adjacent blocks are in the wrong order: the block starting with `function formatRadiusError(error: unknown): string {` belongs before the block starting with `function logRadiusRetry(`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 97:

```ts
function formatRadiusError(error: unknown): string {
  if (error instanceof RadiusHttpError) {
    return `HTTP ${error.status}: ${error.message}`;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}

function logRadiusRetry(
```

Around line 109:

```ts
export function getRadiusUrl(): string {
```

Make exactly this change; do not modify anything else.