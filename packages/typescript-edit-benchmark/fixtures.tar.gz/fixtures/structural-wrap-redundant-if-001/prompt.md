# Fix a bug in `bash-spawn-hook.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 14 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 14:

```ts
  const cwd = process.cwd();

  const bashTool = createBashTool(cwd, {
    spawnHook: ({ command, cwd, env }) => ({
      command: `source ~/.profile\n${command}`,
      cwd,
      env: { ...env, PI_SPAWN_HOOK: '1' },
    }),
  });

  pi.registerTool({
    ...bashTool,
    execute: async (id, params, signal, onUpdate, _ctx) => {
      return bashTool.execute(id, params, signal, onUpdate);
    },
  });
```

Make exactly this change; do not modify anything else.