# Fix a bug in `utils.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 80 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 80:

```ts
  try {
    return JSON.stringify(value) ?? 'undefined';
  } catch {
    return '[unserializable]';
```

Make exactly this change; do not modify anything else.