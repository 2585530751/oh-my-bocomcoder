# Fix a bug in `branch-summarization.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 112 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 112:

```ts
  switch (entry.type) {
    case 'message':
      if (entry.message.role === 'toolResult') return undefined;
      return entry.message;

    case 'custom_message':
      return createCustomMessage(
        entry.customType,
        entry.content,
        entry.display,
        entry.details,
        entry.timestamp,
      );

    case 'branch_summary':
      return createBranchSummaryMessage(entry.summary, entry.fromId, entry.timestamp);

    case 'compaction':
      return createCompactionSummaryMessage(entry.summary, entry.tokensBefore, entry.timestamp);
    case 'thinking_level_change':
    case 'model_change':
    case 'active_tools_change':
    case 'custom':
    case 'label':
    case 'session_info':
    case 'leaf':
      return undefined;
```

Make exactly this change; do not modify anything else.