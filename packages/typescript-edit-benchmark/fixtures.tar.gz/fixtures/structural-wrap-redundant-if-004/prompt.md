# Fix a bug in `google-vertex.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 137 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 137:

```ts
                    stream.push({
                      type: 'text_end',
                      contentIndex: blocks.length - 1,
                      content: currentBlock.text,
                      partial: output,
                    });
```

Make exactly this change; do not modify anything else.