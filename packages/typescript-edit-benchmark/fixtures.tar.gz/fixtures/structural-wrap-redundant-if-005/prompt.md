# Fix a bug in `extensions.eval.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 20 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 20:

```ts
    const result = await run([
      {
        type: 'prompt',
        content:
          'Create a Pi extension with a hello tool that takes a name and returns a greeting. For example, passing Bob should return `Hello, Bob!`.',
      },
      { type: 'reload' },
      {
        type: 'prompt',
        content: 'Use the hello tool to greet Bob.',
      },
    ]);

    expect(result.output.response).toBe('Hello, Bob!');
    expect(result.output.extensionPaths).toHaveLength(1);
    expect(result.output.toolDefinitions).toContainEqual(
      expect.objectContaining({ name: 'hello' }),
    );
    expect(result.errors).toEqual([]);
    expect(toolCalls(result.session)).toContainEqual({
      name: 'hello',
      arguments: { name: 'Bob' },
      status: 'ok',
      result: 'Hello, Bob!',
    });
```

Make exactly this change; do not modify anything else.