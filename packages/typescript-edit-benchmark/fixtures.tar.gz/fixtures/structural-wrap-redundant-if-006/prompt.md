# Fix a bug in `env-api-keys.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 158 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 158:

```ts
    const hasCredentials = hasVertexAdcCredentials(env);
    const hasProject = !!(
      getProviderEnvValue('GOOGLE_CLOUD_PROJECT', env) || getProviderEnvValue('GCLOUD_PROJECT', env)
    );
    const hasLocation = !!getProviderEnvValue('GOOGLE_CLOUD_LOCATION', env);

    if (hasCredentials && hasProject && hasLocation) {
      return '<authenticated>';
```

Make exactly this change; do not modify anything else.