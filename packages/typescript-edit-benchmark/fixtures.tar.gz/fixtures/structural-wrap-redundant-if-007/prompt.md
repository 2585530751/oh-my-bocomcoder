# Fix a bug in `test-theme-colors.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 182 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 182:

```ts
  process.env.COLORTERM = 'truecolor';
  initTheme(themeName);

  const parseAnsiRgb = (ansi: string): [number, number, number] | null => {
    const match = ansi.match(/38;2;(\d+);(\d+);(\d+)/);
    return match ? [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3], 10)] : null;
  };

  const getContrastVsWhite = (colorName: string): string => {
    const ansi = theme.getFgAnsi(colorName as Parameters<typeof theme.getFgAnsi>[0]);
    const rgb = parseAnsiRgb(ansi);
    if (!rgb) return '(default)';
    const ratio = getContrast(rgb, 1.0);
    const pass = ratio >= 4.5 ? 'AA' : ratio >= 3.0 ? 'AA-lg' : 'FAIL';
    return `${ratio.toFixed(2)}:1 ${pass}`;
  };

  const getContrastVsBlack = (colorName: string): string => {
    const ansi = theme.getFgAnsi(colorName as Parameters<typeof theme.getFgAnsi>[0]);
    const rgb = parseAnsiRgb(ansi);
    if (!rgb) return '(default)';
    const ratio = getContrast(rgb, 0.0);
    const pass = ratio >= 4.5 ? 'AA' : ratio >= 3.0 ? 'AA-lg' : 'FAIL';
    return `${ratio.toFixed(2)}:1 ${pass}`;
  };

  const logColor = (name: string): void => {
    const sample = theme.fg(name as Parameters<typeof theme.fg>[0], 'Sample text');
    const cw = getContrastVsWhite(name);
    const cb = getContrastVsBlack(name);
    console.log(`${name.padEnd(20)} ${sample}  white: ${cw.padEnd(12)} black: ${cb}`);
  };

  console.log(`\n=== ${themeName} theme (WCAG AA = 4.5:1) ===`);

  console.log('\n--- Core UI ---');
  [
    'accent',
    'border',
    'borderAccent',
    'borderMuted',
    'success',
    'error',
    'warning',
    'muted',
    'dim',
  ].forEach(logColor);

  console.log('\n--- Markdown ---');
  [
    'mdHeading',
    'mdLink',
    'mdCode',
    'mdCodeBlock',
    'mdCodeBlockBorder',
    'mdQuote',
    'mdListBullet',
  ].forEach(logColor);

  console.log('\n--- Diff ---');
  ['toolDiffAdded', 'toolDiffRemoved', 'toolDiffContext'].forEach(logColor);

  console.log('\n--- Thinking ---');
  ['thinkingOff', 'thinkingMinimal', 'thinkingLow', 'thinkingMedium', 'thinkingHigh'].forEach(
    logColor,
  );

  console.log('\n--- Backgrounds ---');
  console.log('userMessageBg:', theme.bg('userMessageBg', ' Sample '));
  console.log('toolPendingBg:', theme.bg('toolPendingBg', ' Sample '));
  console.log('toolSuccessBg:', theme.bg('toolSuccessBg', ' Sample '));
  console.log('toolErrorBg:', theme.bg('toolErrorBg', ' Sample '));
  console.log();
```

Make exactly this change; do not modify anything else.