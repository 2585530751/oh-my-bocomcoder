# Fix a bug in `utilities.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 136 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 136:

```ts
  return {
    role: 'assistant' as const,
    content: [{ type: 'text' as const, text }],
    api: 'anthropic-messages' as const,
    provider: 'anthropic',
    model: 'test',
    usage: {
      input: 1,
      output: 1,
      cacheRead: 0,
      cacheWrite: 0,
      totalTokens: 2,
      cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
    },
    stopReason: 'stop' as const,
    timestamp: Date.now(),
  };
```

Make exactly this change; do not modify anything else.