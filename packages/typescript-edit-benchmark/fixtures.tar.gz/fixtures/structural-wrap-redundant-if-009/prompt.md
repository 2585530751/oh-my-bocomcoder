# Fix a bug in `model-status.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 13 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 13:

```ts
  pi.on('model_select', async (event, ctx) => {
    const { model, previousModel, source } = event;

    // Format model identifiers
    const next = `${model.provider}/${model.id}`;
    const prev = previousModel ? `${previousModel.provider}/${previousModel.id}` : 'none';

    // Show notification on change
    if (source !== 'restore') {
      ctx.ui.notify(`Model: ${next}`, 'info');
    }

    // Update status bar with current model
    ctx.ui.setStatus('model', `🤖 ${model.id}`);

    // Log change details (visible in debug output)
    console.log(`[model_select] ${prev} → ${next} (${source})`);
  });
```

Make exactly this change; do not modify anything else.