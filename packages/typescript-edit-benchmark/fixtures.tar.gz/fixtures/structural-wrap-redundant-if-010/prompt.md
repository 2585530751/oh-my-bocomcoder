# Fix a bug in `extension-selector.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 52 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 52:

```ts
      this.countdown = new CountdownTimer(
        opts.timeout,
        opts.tui,
        (s) => this.titleText.setText(theme.fg('accent', theme.bold(`${this.baseTitle} (${s}s)`))),
        () => this.onCancelCallback(),
      );
```

Make exactly this change; do not modify anything else.