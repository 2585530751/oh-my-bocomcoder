# Fix a bug in `tools-manager.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 214 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 214:

```ts
    // Windows ships bsdtar as tar.exe, which supports zip files. Prefer the
    // System32 binary over Git Bash's GNU tar, which does not handle zip archives.
    const tarFailure = runExtractionCommand(getWindowsTarCommand(), [
      'xf',
      archivePath,
      '-C',
      extractDir,
    ]);
    if (!tarFailure) return;
    failures.push(tarFailure);

    const script =
      "& { param($archive, $destination) $ErrorActionPreference = 'Stop'; Expand-Archive -LiteralPath $archive -DestinationPath $destination -Force }";
    const powershellFailure = runExtractionCommand('powershell.exe', [
      '-NoLogo',
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      script,
      archivePath,
      extractDir,
    ]);
    if (!powershellFailure) return;
    failures.push(powershellFailure);
```

Make exactly this change; do not modify anything else.