# Fix a bug in `stdin-buffer.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 355 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 355:

```ts
        const pastedContent = this.pasteBuffer.slice(0, endIndex);
        const remaining = this.pasteBuffer.slice(endIndex + BRACKETED_PASTE_END.length);

        this.pasteMode = false;
        this.pasteBuffer = '';
        this.pendingKittyPrintableCodepoint = undefined;

        this.emit('paste', pastedContent);

        if (remaining.length > 0) {
          this.process(remaining);
```

Make exactly this change; do not modify anything else.