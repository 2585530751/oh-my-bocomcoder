# Fix a bug in `edit.ts`

A string literal contains a lookalike unicode dash.

Replace this (starting on line 14):

```ts
import { resolveToolPath } from './path\u2013utils.ts';
```

with:

```ts
import { resolveToolPath } from './path-utils.ts';
```

Make exactly this change; do not modify anything else.