# Fix a bug in `prompt-templates.ts`

A string literal contains a lookalike unicode dash.

The bug is near the top of the file.

Replace this:

```ts
  'argument\u2013hint'?: string;
```

with:

```ts
  'argument-hint'?: string;
```

Make exactly this change; do not modify anything else.